<?php

namespace MMA\CustomApi\Api;

interface NewProductsRepositoryInterface extends ProductsRepositoryInterface {

}