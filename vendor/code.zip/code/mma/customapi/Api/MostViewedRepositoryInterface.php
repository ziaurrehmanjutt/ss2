<?php

namespace MMA\CustomApi\Api;

interface MostViewedRepositoryInterface extends ProductsRepositoryInterface {

}