<?php

namespace OxCom\MagentoTopProducts\Api\Data;

/**
 * Interface ProductInterface
 *
 * @api
 * @package OxCom\MagentoTopProducts\Api\Data
 */
interface ProductInterface extends \Magento\Catalog\Api\Data\ProductInterface
{
}
